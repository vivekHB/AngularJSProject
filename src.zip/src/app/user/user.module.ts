import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { UserRoutingModule } from './user-routing.module';
import { UserProfile } from './UserProfile.component';
import { Login } from './login.component';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
//import { UserService } from './user.service';


// @NgModule({
//   declarations: [UserProfile],
//   imports: [
//     CommonModule, 
    
//     ],
//   providers : [],
//   exports: [
//     UserProfile
//   ]
//  })
@NgModule({
  declarations: [UserProfile, Login],
  imports: [
    CommonModule,
    UserRoutingModule,
    FormsModule,
    ReactiveFormsModule
   
    ],
  providers : [],
  exports: [
    UserProfile
  ]
 })
export class UserModule { }