import { Component, OnInit, Input,Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'course-thumbnail',
  template: `<div class="well hoverwell thumnnail">
  <h2>Name: {{tempCourse?.name}}</h2>
  <div>Date: {{tempCourse?.date}}</div>
  <div [ngSwitch] = "tempCourse?.time">Time: {{tempCourse?.time}} 
    <span *ngSwitchCase="'8:00 am'">Early Start</span> 
    <span *ngSwitchCase="'10:00 am'">Late Start</span> 
    <span *ngSwitchDefault>Normal Start</span>
  </div>
  <div>Price: {{tempCourse?.price}}</div>
  <div *ngIf="tempCourse?.location">Location : <span>{{tempCourse?.location?.trainingRoom}},</span>
  <span class="pad-left">{{tempCourse?.location?.building}},{{tempCourse?.location?.city}}</span></div>
  <div *ngIf="tempCourse?.onlineUrl">Online Url: {{tempCourse?.onlineUrl}}</div>
  <button class="btn btn-primary" (click) = "transferDataToParent()">Enroll</button></div>`,
  styles:[`.pad-left{margin-left: 10px;}
		 .well div {color: #bbb;}`
	   ]
})
export class CourseThumbnailComponent {
  @Input() tempCourse : any;
  @Output() eventCaptured = new EventEmitter();
  foo = 'Hello world';
  transferDataToParent() {
    this.eventCaptured.emit(this.tempCourse.name);
  }
  callMe(){
    console.log("Call me function invoked");
  }
}
