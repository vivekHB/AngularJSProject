import { Component } from '@angular/core';
import { CourseService } from '../shared/course.service';
import { Course } from '../shared/course.model';
@Component({
  selector: 'app-course-list',
  // template:   `<app-display-comp *ngFor="let course of courses"  [tempcourse]="course"></app-display-comp>`


  // templateUrl: './course-list.component.html',
  template: `<div>
  <h1>Upcoming Virtusa Courses</h1>
</div>
  <app-display-comp #DisplayCompComponent (eventCapture)="parentFunc($event)" *ngFor="let course of courses" [tempcourse]="course"></app-display-comp>
           <div> 
            <button  class="btn btn-primary" (click) = "DisplayCompComponent.callMe()"> second  </button>
           </div>
             `
  //   template: '<div>\ {{DisplayCompComponent.foo}}
  //   <h1> welcome to my child  home </h1>\
  //  </div>\



  // styleUrls: ['./course-list.component.css']
})
export class CourseListComponent {
  courseList : boolean =true;
  courses: Course[];
  constructor(private courseService: CourseService) {
    //this.courses = courseService.getAllCourses();
    courseService.getAllCourses().subscribe((data) => this.courses = data)
  }

  parentFunc(data) {
    console.log(data)
  }



}


