import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CourseService } from '../shared/course.service';

@Component({
  templateUrl: './coursedetail.component.html'      
})
export class CourseDetailComponent {
  course : any;
  constructor(private courseService : CourseService, private activatedRoute : ActivatedRoute){
    this.course = courseService.getCourseById(+activatedRoute.snapshot.params['id']);
  }
  
  
}
