import { Component, Input,Output ,EventEmitter} from '@angular/core';
import {CourseService} from '../shared/course.service';
import { ActivatedRoute } from '@angular/router';
import { Course } from '../shared/course.model';
@Component({
  selector: 'app-display-comp',
  templateUrl: './display-comp.component.html',
//  template:`           <div>
//             Name = {{tempcourse?.name}}
// </div>
// <div *ngIf="tempcourse?.location">
//             Location traningRoom = {{tempcourse?.location?.trainingRoom}}
// </div>
// <div [hidden]="tempcourse?.onlineUrl">
//             Online Url = {{tempcourse?.onlineUrl}}
// </div>
// <div>
//             Date = {{tempcourse?.date}}
// <div ><br>      </div>`





styleUrls: ['./display-comp.component.css']
})
export class DisplayCompComponent  {
@Input() tempcourse : any;
//@Output() eventCapture = new EventEmitter();
name = "haemant"
// add( i: number ,j: number){
//   return i+j;
// }
// onClick(){
//   console.log("child component button clicked");
//   //this.eventCapture.emit(this.tempcourse.name);
// }
callMe(){
   console.log(this.name)
 } 
 // <button class="btn btn-primary" (click) = "onClick()"> email </button><br>'
// <div [ngSwitch]="tempcourse?.time">\
// <span *ngSwitchCase="8"":"00 am"> Early Start </span>\
// <span *ngSwitchCase="10:00 am"> Early Start </span>\
// <span *ngSwitchDefault> regular Start </span>\
// Time = {{tempcourse?.time}}\
// </div>\
courses :Course[];
constructor(private courseService : CourseService, private activateRoute : ActivatedRoute){
  this.tempcourse=courseService.getCourseById(this.activateRoute.snapshot.params['a']);
}
}
