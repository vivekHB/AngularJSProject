import { Component } from '@angular/core';
import { UserService } from './user.service';
import { Router } from '@angular/router';

@Component({
  templateUrl: `./login.component.html`,
  styles : ['em{float:right; color: #E05c65; padding-left-10px;}']
})
export class Login {
  constructor(private router : Router,private userService: UserService){}
  login(loginForm){
  this.userService.login(loginForm)
  this.router.navigate(['user/Profile'])
   console.log(loginForm)
  }
}
