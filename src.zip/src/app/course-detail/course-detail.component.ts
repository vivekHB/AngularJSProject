import { Component, OnInit } from '@angular/core';
import { CourseService } from '../shared/course.service';
import { ActivatedRoute } from '@angular/router';
import { Course } from '../shared/course.model';

@Component({
  selector: 'app-course-detail',
  templateUrl: './course-detail.component.html',
  styleUrls: ['./course-detail.component.css']
})
export class CourseDetailComponent implements OnInit {
  tempcourse : Course;
  constructor( private courseService : CourseService, private activateRoute : ActivatedRoute) {
  //this.tempcourse=courseService.getCourseById(+activateRoute.snapshot.params['a']);
  }

  ngOnInit() {
    this.tempcourse=this.courseService.getCourseById(+this.activateRoute.snapshot.params['a']);
  }

}
