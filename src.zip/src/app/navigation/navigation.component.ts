import { Component, OnInit } from '@angular/core';
import { UserService } from '../user/user.service';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  //styleUrls: ['./navigation.component.css']
styles:[`
.nav.navbar-nav {font-size : 15px;},
#searchForm {margin-right:100px;},+
@media (max-width : 1200px){#searchForm{dispaly:none}}
li > a.active{color: orange;}`],
})
export class NavigationComponent implements OnInit {

  constructor(public autheticatedUser:UserService) { }
  
  ngOnInit() {
   
  }

}
