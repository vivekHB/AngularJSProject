import { NgModule } from '@angular/core';
 import { Routes, RouterModule } from '@angular/router';
import { UserProfile } from './UserProfile.component';
import { Login } from './login.component';

//import { UserProfile } from './User/userProfile.component';
// import { CourseListComponent } from './course-list/course-list.component';
// import { DisplayCompComponent } from './display-comp/display-comp.component';
// import { CourseDetailComponent } from './course-detail/course-detail.component';
// import { CourseRouterActivatorService } from './can-activate.service';
// import { CreateCourseComponent } from './create-course/create-course.component';
// import { Error404Component } from './error404/error404.component';
// import { ProfileComponent } from './porfile/porfile.component';

const routes: Routes = [
  {path:'Profile',component : UserProfile},
  {path:'login',component:Login},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})


//import {UserProfileComponent} from './user.profile.component'

export class UserRoutingModule { }
