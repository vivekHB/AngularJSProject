import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  //templateUrl: './test.component.html',
    template : '<h1> Hemant test </h1>\
                 <img src="/assets/images/angularconnect-shield">'           
 
})
export class TestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
