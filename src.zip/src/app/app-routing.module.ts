import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CourseListComponent } from './course-list/course-list.component';
import { DisplayCompComponent } from './display-comp/display-comp.component';
import { CourseDetailComponent } from './course-detail/course-detail.component';
import { CourseRouterActivatorService } from './can-activate.service';
import { CreateCourseComponent } from './create-course/create-course.component';
import { Error404Component } from './error404/error404.component';
//import { ProfileComponent } from './porfile/porfile.component';
//import { UserProfile } from './user/UserProfile';
import { UserModule } from './user/user.module';

const routes: Routes = [
  {path:'user',loadChildren :'./user/user.module#UserModule'},
  {path:'courses',component : CourseListComponent},
  // {path:'courses/Profile',component : ProfileComponent},
  // if this funtion retrn true the link wil be deactivated,
  {path:'courses/createCourse', component : CreateCourseComponent, canDeactivate : ['canDeactivateCreateCourse']},  
  
  //{path:'courses/:a',component : DisplayCompComponent},
  //route Gaurd,
  {path:'courses/:a',component : CourseDetailComponent, canActivate : [CourseRouterActivatorService]}, 
  {path:'',redirectTo : '/courses',pathMatch: 'full'},
  {path:'**',redirectTo:'/404',pathMatch:'full'},
  {path:'404',component :Error404Component},
  //{path:'user/Profile',component : UserProfile},
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
