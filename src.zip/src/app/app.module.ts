import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DateComponent } from './date.component';
import { HelloComponent } from './hello.component';
import { TestComponent } from './test/test.component';
import { CourseListComponent } from './course/courselist.component';
import { CourseThumbnailComponent } from './course/coursethumbnail.component';
import { NavBarComponent } from './navbar/navbar.component';
import { CourseService } from './shared/course.service';
import { CourseDetailComponent } from './course/coursedetail.component';
import { Error404Component } from './error/error.component';


@NgModule({
  declarations: [
    AppComponent, DateComponent, HelloComponent, TestComponent, 
    CourseListComponent, CourseThumbnailComponent, 
    NavBarComponent, CourseDetailComponent, Error404Component ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers : [CourseService],
  bootstrap: [AppComponent]
})
export class AppModule { }
