import { Component } from '@angular/core';

@Component({
  selector: 'root-component',
  //template: '<app-course-list></app-course-list>',
  template:`<app-navigation></app-navigation> 
  <router-outlet></router-outlet>`,
  
  
  //templateUrl: './app.component.html','
 // template:'<h1> Hemant app.componet.ts <h1>\
  //<img src="/assets/images/angularconnect-shield.png">',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angProj';
  date = new Date()
}
