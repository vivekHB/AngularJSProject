export interface Course{
    id : number 
    name : string
    date : Date
    time :string
    price : number
    imageUrl : string
    duration ?: number
    onlineUrl? : string
    location ? : {
        trainingRoom : string
        building : string
        city : string
    }
}