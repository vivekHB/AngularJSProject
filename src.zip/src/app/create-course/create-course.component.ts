// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-create-course',
//   templateUrl: './create-course.component.html',
//   styleUrls: ['./create-course.component.css']
// })
// export class CreateCourseComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }
import { Component } from '@angular/core';
import {Router} from '@angular/router';
import { CourseService } from '../shared/course.service';
@Component({
  // template: `<h1> New Course</h1>
  //           <hr>
  //           <div class="col-md-6">
  //           <h3>[Create Course Component]</h3>
  //           <br/>
  //           <br/>
  //           <button type="submit" class="btn btn-primary">Save</button>
  //           <button type="button" (click)="cancel()" class="btn btn-default">Cancel</button>
  //           </div>`
  templateUrl:'./create-course.component.html',
  styles : ['em{float:right; color: #E05c65; padding-left-10px;}']
})
export class CreateCourseComponent {
  isDirty : boolean =true;
  back : any;
  
  
  constructor(private router : Router,private courseService: CourseService){}
  saveCourse(newCourseForm){
    this.courseService.saveCourse(newCourseForm)
    this.router.navigate(['/courses'])
   console.log(newCourseForm)
  }
  
  cancel(){
    this.back = this.router.navigate(['/courses']);
  }
}