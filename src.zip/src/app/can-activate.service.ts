import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot } from '@angular/router';
import { CourseService } from './shared/course.service';

@Injectable({
  providedIn: 'root'
})
export class CourseRouterActivatorService implements CanActivate {
  constructor(private courseService: CourseService, private router: Router) {

  }
  canActivate(route: ActivatedRouteSnapshot) {
    const courseExists = !!this.courseService.getCourseById(+route.params['a'])
    if(!courseExists)
      this.router.navigate(['/404'])
    return courseExists
  }
}
