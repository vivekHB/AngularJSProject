import { Component } from '@angular/core';

@Component({
  selector: 'hello',
  template: '<h2 class="red">Hello</h2>'
})
export class HelloComponent {}
