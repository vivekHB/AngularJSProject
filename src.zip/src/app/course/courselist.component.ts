import { Component, OnInit } from '@angular/core';
import { CourseService } from '../shared/course.service';

@Component({
  selector: 'course-list',
  template: `<div>
    <h1>Upcoming Virtusa Courses</h1>
    <hr>
    <div class="row">
    <div *ngFor="let course of courses"  class="col-md-5"> 
    <course-thumbnail #courseThumbnail (eventCaptured)="parentFunction($event)" 
     [tempCourse] = "course"></course-thumbnail>
    </div></div>
    </div>
    `      
})
export class CourseListComponent {
  title = "Angular";
  courses : any[];
  constructor(private courseService : CourseService){
    this.courses = courseService.getAllCourses();
  }
  
  parentFunction(data) {
    console.log("parent:" + data);
  }
  
  
}
