import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';
//import { CourseListComponent } from './course-list/course-list.component';
import { DisplayCompComponent } from './display-comp/display-comp.component';
import { NavigationComponent } from './navigation/navigation.component';
import {CourseService} from './shared/course.service';
import { CourseDetailComponent } from './course-detail/course-detail.component';
import { Error404Component } from './error404/error404.component';
//import { CreateCourseComponent } from './create-course/create-course.component';
import { durationPipe } from './pipe/durationPipe';
import{CreateCourseComponent,CourseListComponent,} from './index';

import {CourseRouterActivatorService} from './can-activate.service';
import { UserModule } from './user/user.module';
import { FormsModule } from '@angular/forms';
import { UserService } from './user/user.service';

import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    TestComponent,
    CourseListComponent,
    DisplayCompComponent,
    CourseDetailComponent,
    NavigationComponent,
    Error404Component,
    CreateCourseComponent,
    durationPipe,
    //ProfileComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [CourseService,
    CourseRouterActivatorService,
            {provide:'canDeactivateCreateCourse',
          useValue:checkDirtyState},
          UserService
        ],
  bootstrap: [AppComponent]
})
export class AppModule { }
export function checkDirtyState(createcourse : CreateCourseComponent, CourseListComponent:CourseDetailComponent){
  if(createcourse.isDirty){
    return window.confirm("do u want to close before saving ???????")
  }
}