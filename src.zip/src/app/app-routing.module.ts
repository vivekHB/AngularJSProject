import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {CourseListComponent} from './course/courselist.component';
import {CourseDetailComponent} from './course/coursedetail.component';
import {Error404Component} from './error/error.component';

const routes: Routes = [
  {path: 'courses', component : CourseListComponent},
  {path: 'courses/:id', component : CourseDetailComponent},
  {path: '404', component : Error404Component},
  {path: '', redirectTo: '/courses', pathMatch : 'full'},
  {path: '**', redirectTo: '/404', pathMatch : 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
