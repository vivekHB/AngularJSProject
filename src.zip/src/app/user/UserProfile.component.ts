// import { Component } from '@angular/core';

// @Component({
//   selector: 'profile-component',
//   //template: '<app-course-list></app-course-list>',
//   //template:
  
  
//   //templateUrl: './app.component.html','
//  // template:'<h1> Hemant app.componet.ts <h1>\
//   //<img src="/assets/images/angularconnect-shield.png">',
//   templateUrl: './userProfile.component.html',
//  // styleUrls: ['./app.component.css']
// })
// export class UserProfile {
//   // title = 'angProj';
//   // date = new Date()
// }

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from './user.service';
//import { AuthenticateService } from './authenticate.service'

@Component({
  templateUrl: `./userProfile.component.html`,
  styles : ['em{float:right; color: #E05c65; padding-left-10px;}']
})
export class UserProfile implements OnInit {
  profileForm: FormGroup;
  constructor(private router: Router, private authenticteService: UserService) { }

  ngOnInit() {
    let firstName = new FormControl(this.authenticteService.user.firstName);
    let lastName = new FormControl(this.authenticteService.user.lastName);
    this.profileForm = new FormGroup({
      firstName: firstName,
      lastName: lastName
    })
  }

  saveUser(profileForm){
    this.authenticteService.updateUser(profileForm.firstName , profileForm.lastName)
  }
cancel()
{ this.router.navigate(['/courses']) }
}
//this.authenticteService.currentUser.firstName, Validators.required
//this.authenticteService.currentUser.lastName, Validators.required   this.profileForm.firstName ,this.profileForm.lastName