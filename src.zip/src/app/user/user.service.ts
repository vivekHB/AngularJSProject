// import {Injectable} from '@angular/core';
// import { Router } from '@angular/router';
// import { IUser } from './userModel';


// @Injectable()
// export class UserService{
//   user : IUser
//     verifyUser(loginForm){
     
//       this.user = {
//       userName : loginForm.userName,
//       passWord : loginForm.password,
//       firstName : "virtusa",
//       lastName : "Suamnt"
//       }
      
//       this.router.navigate(['/courses'])
//       }

// isAuthenticated(){
//         return !!this.user
//       }
      
//       updateUser( first: string, last: string){
//         this.user = {
//           userName : 'test',
//           passWord : 'test',
//           firstName : first,
//           lastName : last
//           }
//       }

//     constructor(private router : Router){}
// }
//  const loginName = "Hemant"
//  const psw = "1234"

import {Injectable} from '@angular/core';
import { IUser } from './userModel';

@Injectable()
export class UserService {
  user : IUser;

  login(loginForm){
     
      this.user = {
        
        password : loginForm.password,
        userName: loginForm.userName,
        firstName: 'Virtusa',
        lastName: 'Angular'
        }
      }

      updateUser(first : string, last : string){
        this.user = {
          password : 'test',
          userName: 'test',
          firstName: first,
          lastName: last
          }
        }
      isAuthenticated() {
        return !!this.user
        //return true
      }
}