export * from './course-detail/course-detail.component';
export * from './course-list/course-list.component';
export * from './create-course/create-course.component';
export * from './display-comp/display-comp.component';
export * from './navigation/navigation.component';


